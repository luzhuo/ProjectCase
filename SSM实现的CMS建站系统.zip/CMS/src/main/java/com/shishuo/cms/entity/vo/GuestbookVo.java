package com.shishuo.cms.entity.vo;

import com.shishuo.cms.entity.Guestbook;

public class GuestbookVo extends Guestbook {

}
