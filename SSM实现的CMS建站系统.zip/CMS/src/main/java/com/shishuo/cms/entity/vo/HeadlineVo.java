package com.shishuo.cms.entity.vo;

import com.shishuo.cms.entity.Headline;

public class HeadlineVo extends Headline {

}
