/*
 *	Copyright © 2013 Changsha Shishuo Network Technology Co., Ltd. All rights reserved.
 *	长沙市师说网络科技有限公司 版权所有
 *	http://www.shishuo.com
 */
package com.shishuo.cms;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * 
 * @author Herbert
 * 
 */
public class FOO {

	public static void main(String[] args) {
		System.out.println("欢迎来到Java的世界，欢迎使用师说CMS。");
		System.out.println(StringUtils.isAllLowerCase("kjk"));
		System.out.println("/".endsWith("/"));

	}
}
