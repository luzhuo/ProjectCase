package com.shishuo.cms.constant;

public class GuestbookConstant {

	public static enum status {
		display, hidden, init
	};
}
