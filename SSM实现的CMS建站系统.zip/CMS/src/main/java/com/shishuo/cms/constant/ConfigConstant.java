/*
 *	Copyright © 2013 Changsha Shishuo Network Technology Co., Ltd. All rights reserved.
 *	长沙市师说网络科技有限公司 版权所有
 *	http://www.shishuo.com
 */

package com.shishuo.cms.constant;

import org.springframework.stereotype.Component;

/**
 * 系统配置常量
 * 
 * @author Herbert
 */
@Component
public class ConfigConstant {

	/**
	 * 默认的模板
	 */
	public static String DEFAUTL_TEMPLATE = "default";
	public static String SHISHUO_TEMPLATE = "shishuo_template";
}
